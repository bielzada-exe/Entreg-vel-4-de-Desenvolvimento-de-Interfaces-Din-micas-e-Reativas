# Gerenciador de Tarefas

## Sobre o projeto
Aplicação criada com React para cadastrar e organizar tarefas.

## Funcionalidades
- Adicionar tarefas.
- Mostrar tarefas cadastradas.
- Atualizar o título da aba.
- Contar o tempo da página aberta.

## Tecnologias
- React
- JavaScript
- CSS
- useState
- useEffect

## Reflexão

**1. O que acontece se omitirmos o array de dependências do useEffect?**

Ele será executado após cada renderização do componente.

**2. Como funciona o fluxo de dados no Lifting State Up?**

O estado fica no componente pai e é compartilhado com os filhos através de props.

## Conclusão
A atividade ajudou a entender como compartilhar estados entre componentes e utilizar o useEffect.   