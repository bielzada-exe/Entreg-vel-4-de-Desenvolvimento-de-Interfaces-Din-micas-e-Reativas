function Lista({ tarefas }) {
  return (
    <div>
      <h2>Minhas tarefas</h2>

      <ul>
        {tarefas.map((tarefa) => (
          <li key={tarefa.id}>
            {tarefa.texto}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Lista;