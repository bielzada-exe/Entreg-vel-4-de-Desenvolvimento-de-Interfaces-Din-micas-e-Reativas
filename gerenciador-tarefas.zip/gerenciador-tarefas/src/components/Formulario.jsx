
import { useState } from "react";

function Formulario({ adicionarTarefa }) {
  const [texto, setTexto] = useState("");

  function enviarFormulario(event) {
    event.preventDefault();

    if (texto.trim() === "") {
      return;
    }

    adicionarTarefa(texto);
    setTexto("");
  }

  return (
    <form onSubmit={enviarFormulario}>
      <input
        type="text"
        placeholder="Digite uma tarefa..."
        value={texto}
        onChange={(event) => setTexto(event.target.value)}
      />

      <button type="submit">Adicionar</button>
    </form>
  );
}

export default Formulario;
