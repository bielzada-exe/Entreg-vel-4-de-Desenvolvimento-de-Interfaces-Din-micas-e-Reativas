
import { useState, useEffect } from "react";
import Formulario from "./components/Formulario";
import Lista from "./components/Lista";
import "./App.css";

function App() {
  const [tarefas, setTarefas] = useState([]);
  const [tempo, setTempo] = useState(0);

  function adicionarTarefa(texto) {
    const novaTarefa = {
      id: Date.now(),
      texto: texto
    };

    setTarefas((tarefasAtuais) => [
      ...tarefasAtuais,
      novaTarefa
    ]);
  }

  useEffect(() => {
    const pendentes = tarefas.length;
    document.title = `${pendentes} tarefas pendentes`;
  }, [tarefas]);

  useEffect(() => {
    const intervalo = setInterval(() => {
      setTempo((tempoAtual) => tempoAtual + 1);
    }, 1000);

    return () => {
      clearInterval(intervalo);
    };
  }, []);

  return (
    <div className="container">
      <h1>Gerenciador de Tarefas</h1>

      <p>Tempo com a página aberta: {tempo} segundos</p>

      <Formulario adicionarTarefa={adicionarTarefa} />

      <Lista tarefas={tarefas} />

      <p>Total de tarefas: {tarefas.length}</p>
    </div>
  );
}

export default App;
